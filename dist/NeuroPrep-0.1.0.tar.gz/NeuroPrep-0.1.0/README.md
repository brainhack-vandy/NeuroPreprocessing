# NeuroPrep
This repository provides an implementation for preprocessing fMRI
